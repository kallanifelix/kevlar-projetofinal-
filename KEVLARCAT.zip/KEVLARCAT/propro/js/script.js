$(document).scroll(function(){
        var topWindow = $ (window).scrollTop();
        if(topwindow width <780p)
            {
                $("#divbusca").addClass('not-show');
            }
        else
        {
            $("#divbusca").removeClass('not-show');
        };
    });